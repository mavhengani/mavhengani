package com.example.order_up;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import  android.content.Intent;
import android.view.View;

public class Sign_in extends AppCompatActivity {

    public Button backButton;
    public Button sign_in;
    public Button Tape;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        backButton = (Button) findViewById(R.id.button8);
        sign_in = (Button) findViewById(R.id.button3);
        Tape = (Button) findViewById(R.id.button4);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Sign_in.this,MainActivity.class);
                startActivity(intent);
            }
        });

        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Sign_in.this,FirstPage_Activity.class);
                startActivity(intent);
            }
        });

        Tape.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Sign_in.this,Log_in.class);
                startActivity(intent);
            }
        });
    }
}
