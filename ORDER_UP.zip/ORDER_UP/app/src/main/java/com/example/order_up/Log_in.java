package com.example.order_up;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import  android.content.Intent;
import android.view.View;

public class Log_in extends AppCompatActivity {

    public Button backButton;
    public Button Login;
    public Button Tape;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);


        backButton = (Button) findViewById(R.id.button15);
        Login = (Button) findViewById(R.id.button12);
        Tape = (Button) findViewById(R.id.button14);


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Log_in.this,MainActivity.class);
                startActivity(intent);
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Log_in.this,FirstPage_Activity.class);
                startActivity(intent);
            }
        });

        Tape.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Log_in.this,Sign_in.class);
                startActivity(intent);
            }
        });
    }
}
