package com.example.order_up;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Switch_Button extends AppCompatActivity {

    SwitchCompat switchCompat;
    Button Login;
    Button Signin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_switch__button);

        switchCompat= (SwitchCompat) findViewById(R.id.SWitch);
        Login = (Button) findViewById(R.id.log);
        Signin = (Button) findViewById(R.id.sign);

        SharedPreferences sharedPreferences = getSharedPreferences("save",MODE_PRIVATE);

        switchCompat.setChecked(sharedPreferences.getBoolean("value",true));

        switchCompat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    if (switchCompat.isChecked()){

                        SharedPreferences.Editor editor = (SharedPreferences.Editor) getSharedPreferences("save",MODE_PRIVATE);

                        editor.putBoolean("value",true);
                        editor.apply();
                        switchCompat.setChecked(true);
                    }
                    else {
                        SharedPreferences.Editor editor = (SharedPreferences.Editor) getSharedPreferences("save",MODE_PRIVATE);

                        editor.putBoolean("value",false);
                        editor.apply();
                        switchCompat.setChecked(false);
                    }

                }

        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Switch_Button.this,Log_in.class);
                startActivity(intent);
            }
        });

        Signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Switch_Button.this,Log_in.class);
                startActivity(intent);
            }
        });




    }
}
